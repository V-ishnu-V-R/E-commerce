var express = require("express");
var router = express.Router();
const userController = require("../controller/admin-controller");
const User = require("../models/userModel");
const category=require("../models/categoryModel")

exports.getAdmin=function(req, res, next) {

    res.render('admin/signin');
  }
 exports.getAdminDashboard=function(req, res, next) {
    res.render('admin/dashboard');
  }
 
  exports.getAdminProducts=function(req,res){
    res.render("admin/products")
  }
  exports.getAdminCategory=function(req,res){
    res.render("admin/category")
  }
  exports.getAdminUsers= async function(req,res){
    const userDetails=await User.find().lean()
    res.render("admin/users",{userDetails})     //userdetails os here
  }
  exports.getAddCategory=function(req,res){
    res.render("admin/add-Category")
  }
  exports.createCategory= async function(req,res){
    categoryExist= await category.findOne({category:req.category}).lean()
    if(categoryExist){
      return res.send("Category already exits")
    }
    await category.create(req.body)
    const categoryDetails=await category.find().lean()
    res.redirect("/admin/category",{categoryDetails})


  }
  // exports.createCategory=(req,res)=>{

  //   const newCat=new category({
  //     Category:req.body.name
  //   })
  //   newCat.save()
  // }

  


 
