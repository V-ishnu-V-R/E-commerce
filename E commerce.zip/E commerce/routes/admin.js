var express = require('express');
var router = express.Router();
const adminController = require("../controller/admin-controller");

// /* GET home page. */ admiln home page is the login page and it will go to the dashboard once logged in


router.get('/',adminController. getAdmin);

router.get('/dashboard',adminController.getAdminDashboard );


// router.get('/widget',adminController.getAdminWidget)

router.get('/products',adminController.getAdminProducts)
router.get('/category',adminController.getAdminCategory)
router.get('/users',adminController.getAdminUsers)
router.get("/add-Category",adminController.getAddCategory)
router.post("/add-Category",adminController.createCategory)







module.exports = router;  
  